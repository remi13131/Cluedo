package Cluedo.Interfaces;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class ReponseFen {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReponseFen window = new ReponseFen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ReponseFen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(400, 100, 600, 400);
		frame.setTitle("CLUDEO");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblWhichCardDo = new JLabel("             Which card do you want to show ?");
		lblWhichCardDo.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 17));
		lblWhichCardDo.setBounds(110, 33, 388, 38);
		frame.getContentPane().add(lblWhichCardDo);
		
		JLabel img = new JLabel("img1");
		img.setBounds(65, 82, 118, 177);
		frame.getContentPane().add(img);
		
		JLabel img1 = new JLabel("img2");
		img1.setBounds(214, 82, 118, 177);
		frame.getContentPane().add(img1);
		
		JLabel img2 = new JLabel("img3");
		img2.setBounds(380, 82, 118, 177);
		frame.getContentPane().add(img2);
		
		img.setIcon(new ImageIcon("image\\conservatory.png"));
		img1.setIcon(new ImageIcon("image\\plum.png"));
		img2.setIcon(new ImageIcon("image\\revolver.png"));
		
		JLabel label = new JLabel("       1");
		label.setFont(new Font("Tahoma", Font.BOLD, 15));
		label.setBounds(90, 279, 46, 14);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("       2");
		label_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		label_1.setBounds(243, 279, 46, 14);
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("       3");
		label_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		label_2.setBounds(390, 279, 46, 14);
		frame.getContentPane().add(label_2);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3"}));
		comboBox.setBounds(214, 316, 46, 20);
		frame.getContentPane().add(comboBox);
		
		JButton btnNewButton = new JButton("GO..");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String reponse = comboBox.getSelectedItem().toString();
				
			}
		});
		btnNewButton.setBounds(291, 310, 129, 33);
		frame.getContentPane().add(btnNewButton);


	}
}
