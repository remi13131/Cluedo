package Cluedo.Interfaces;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JList;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class SoloFen {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SoloFen window = new SoloFen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SoloFen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(20, 0, 1300, 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("CLUDEO");
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("         WELCOME TO THE CLUEDO GAME !");
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel.setBounds(422, 11, 478, 28);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblMove = new JLabel("MOVE");
		lblMove.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblMove.setBounds(52, 27,114, 173);
		frame.getContentPane().add(lblMove);
		//  Jlabel pour les images
		final JLabel lblImg = new JLabel("rooms");
		lblImg.setBounds(267, 156, 114, 173);
		frame.getContentPane().add(lblImg);
		
		final JLabel lblImage = new JLabel("weapons");
		lblImage.setBounds(433, 156, 114, 173);
		frame.getContentPane().add(lblImage);
		
		final JLabel lblImage_1 = new JLabel("suspect");
		lblImage_1.setBounds(607, 156, 114, 173);
		frame.getContentPane().add(lblImage_1);
		//***************************************
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 13));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Suggest", "Accuse"}));
		comboBox.setBounds(116, 100, 99, 28);
		frame.getContentPane().add(comboBox);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Kitchen", "Ballroom", "Conservatory", "Dining", "Billard", "Library", "Lounge", "Hall", "Study"}));
		comboBox_1.setToolTipText("");
		comboBox_1.setBounds(267, 100, 114, 28);
		frame.getContentPane().add(comboBox_1);
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox_1.getSelectedItem().toString().equals("Kitchen"))
					lblImg.setIcon(new ImageIcon("image\\kitchen.png"));
				
				if(comboBox_1.getSelectedItem().toString().equals("Ballroom"))
					lblImg.setIcon(new ImageIcon("image\\ballroom.png"));
				
				if(comboBox_1.getSelectedItem().toString().equals("Conservatory"))
					lblImg.setIcon(new ImageIcon("image\\conservatory.png"));
				if(comboBox_1.getSelectedItem().toString().equals("Dining"))
					lblImg.setIcon(new ImageIcon("image\\dining.png"));
				if(comboBox_1.getSelectedItem().toString().equals("Billard"))
					lblImg.setIcon(new ImageIcon("image\\billard.png"));
				if(comboBox_1.getSelectedItem().toString().equals("Library"))
					lblImg.setIcon(new ImageIcon("image\\library.png"));
				if(comboBox_1.getSelectedItem().toString().equals("Lounge"))
					lblImg.setIcon(new ImageIcon("image\\lounge.png"));
				if(comboBox_1.getSelectedItem().toString().equals("Hall"))
					lblImg.setIcon(new ImageIcon("image\\hall.png"));
				if(comboBox_1.getSelectedItem().toString().equals("Study"))
					lblImg.setIcon(new ImageIcon("image\\study.png"));
					
			}
		});
		
		final JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"Candlestick", "Dagger", "Pipe", "Revolver", "Rope", "Spanner"}));
		comboBox_2.setBounds(433, 101, 99, 28);
		frame.getContentPane().add(comboBox_2);
		
		comboBox_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox_2.getSelectedItem().toString().equals("Candlestick"))
					lblImage.setIcon(new ImageIcon("image\\candlestick.png"));
				
				if(comboBox_2.getSelectedItem().toString().equals("Dagger"))
					lblImage.setIcon(new ImageIcon("image\\dagger.png"));
				
				if(comboBox_2.getSelectedItem().toString().equals("Pipe"))
					lblImage.setIcon(new ImageIcon("image\\pipe.png"));
				
				if(comboBox_2.getSelectedItem().toString().equals("Revolver"))
					lblImage.setIcon(new ImageIcon("image\\revolver.png"));
				
				if(comboBox_2.getSelectedItem().toString().equals("Rope"))
					lblImage.setIcon(new ImageIcon("image\\rope.png"));
				
				if(comboBox_2.getSelectedItem().toString().equals("Spanner"))
					lblImage.setIcon(new ImageIcon("image\\spanner.png"));
	
			}
		});
		
		
		final JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"Scarlett", "Plum", "Peacack", "Green", "Mustard", "White"}));
		comboBox_3.setBounds(607, 100, 99, 28);
		frame.getContentPane().add(comboBox_3);
		
		comboBox_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox_3.getSelectedItem().toString().equals("Scarlett"))
					lblImage_1.setIcon(new ImageIcon("image\\scarlett.png"));
				
				if(comboBox_3.getSelectedItem().toString().equals("Plum"))
					lblImage_1.setIcon(new ImageIcon("image\\plum.png"));
				
				if(comboBox_3.getSelectedItem().toString().equals("Peacack"))
					lblImage_1.setIcon(new ImageIcon("image\\peacack.png"));
				
				if(comboBox_3.getSelectedItem().toString().equals("Green"))
					lblImage_1.setIcon(new ImageIcon("image\\green.png"));
				
				if(comboBox_3.getSelectedItem().toString().equals("Mustard"))
					lblImage_1.setIcon(new ImageIcon("image\\mustard.png"));
				
				if(comboBox_3.getSelectedItem().toString().equals("White"))
					lblImage_1.setIcon(new ImageIcon("image\\white.png"));
				
					
			}
		});
		
		
		JButton btnNewButton = new JButton("GO...");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(757, 96, 99, 38);
		frame.getContentPane().add(btnNewButton);
		
		JList list = new JList();
		list.setBounds(1043, 100, 188, 382);
		frame.getContentPane().add(list);
		JButton btnExit = new JButton("EXIT");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnExit.setBounds(1064, 611, 167, 38);
		frame.getContentPane().add(btnExit);
		
		JLabel lblNewLabel_1 = new JLabel("Carte1");
		lblNewLabel_1.setBounds(52, 309, 114, 173);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblCarte = new JLabel("Carte2");
		lblCarte.setBounds(190, 309, 114, 173);
		frame.getContentPane().add(lblCarte);
		
		JLabel lblCarte_1 = new JLabel("Carte3");
		lblCarte_1.setBounds(319, 309, 114, 173);
		frame.getContentPane().add(lblCarte_1);
		
		JLabel lblCarte_2 = new JLabel("Carte4");
		lblCarte_2.setBounds(455, 309, 114, 173);
		frame.getContentPane().add(lblCarte_2);
		
		JLabel lblCarte_3 = new JLabel("Carte5");
		lblCarte_3.setBounds(592, 309, 114, 173);
		frame.getContentPane().add(lblCarte_3);
		
		JLabel lblCarte_4 = new JLabel("Carte6");
		lblCarte_4.setBounds(742, 309, 114, 173);
		frame.getContentPane().add(lblCarte_4);
		
		JLabel lblCarte_5 = new JLabel("Carte7");
		lblCarte_5.setBounds(283, 503, 114, 173);
		frame.getContentPane().add(lblCarte_5);
		
		JLabel lblCarte_6 = new JLabel("Carte8");
		lblCarte_6.setBounds(418, 493, 114, 173);
		frame.getContentPane().add(lblCarte_6);
		
		JLabel lblCarte_7 = new JLabel("Carte9");
		lblCarte_7.setBounds(592, 493, 114, 173);
		frame.getContentPane().add(lblCarte_7);
		
		JButton btnNewButton_1 = new JButton("Play Again");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setBounds(1064, 558, 167, 38);
		frame.getContentPane().add(btnNewButton_1);
		
		
		
		
	}
		

	public final JFrame getFrame() {
		return frame;
	}
	
	
	
}
