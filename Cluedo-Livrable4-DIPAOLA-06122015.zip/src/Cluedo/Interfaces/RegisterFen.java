package Cluedo.Interfaces;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JProgressBar;


public class RegisterFen {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterFen window = new RegisterFen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RegisterFen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {


		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setTitle("CLUDEO");
		JLabel lblType = new JLabel("   TYPE   ");
		lblType.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 14));
		lblType.setBounds(63, 42, 90, 50);
		frame.getContentPane().add(lblType);
		
		final JRadioButton humanbt = new JRadioButton("HUMAN");
		humanbt.setBounds(159, 58, 109, 23);
		frame.getContentPane().add(humanbt);

		
		final JRadioButton computerbt = new JRadioButton("COMPUTER");
		computerbt.setBounds(269, 58, 109, 23);
		frame.getContentPane().add(computerbt);

		
		ButtonGroup butgr = new ButtonGroup();
		butgr.add(humanbt);
		butgr.add(computerbt);
		
		JLabel lblName = new JLabel("   NAME  ");
		lblName.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 14));
		lblName.setBounds(63, 103, 200, 50);
		frame.getContentPane().add(lblName);
		
		final JTextArea Name = new JTextArea();
		Name.setText("Enter your name");
		Name.setBounds(159, 118, 219, 29);
		frame.getContentPane().add(Name);
		Name.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e)
			{
				if (Name.getText().equals("Enter your name"))
						Name.setText("");
			}
		});
		
		JLabel lblIp = new JLabel("   IP");
		lblIp.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 14));
		lblIp.setBounds(68, 159, 200, 50);
		frame.getContentPane().add(lblIp);
		final JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(158, 11, 200, 23);
		progressBar.setVisible(false);
		frame.getContentPane().add(progressBar);
		
		JTextArea IP = new JTextArea();
		IP.setBounds(159, 159, 219, 29);
		frame.getContentPane().add(IP);
		
		JButton btnGo = new JButton("CONNEXION");
		btnGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if((humanbt.isSelected()==true || computerbt.isSelected()==true) && !Name.getText().equals("") && !Name.getText().equals("Enter your name") )
				{progressBar.setVisible(true);
				progressBar.setStringPainted(true);
				progressBar.setValue(70);
				progressBar.setString("wait please 70%");
				progressBar.setForeground(Color.blue);
				}
				else
					JOptionPane.showMessageDialog(frame, "You forget information !!");
			}
		});
		btnGo.setBounds(140, 213, 109, 29);
		frame.getContentPane().add(btnGo);
		
		JButton btnExit = new JButton("EXIT");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame frame = new JFrame();
				String[] options = new String[2];
				options[0] = new String("YES");
			options[1] = new String("NO");
				int  option =JOptionPane.showOptionDialog(frame.getContentPane(),"Are you sure you want to quit?","Quit", 0,JOptionPane.INFORMATION_MESSAGE,null,options,null);
					if(option ==0)
					System.exit(0);
					
			}
				
	
		});
		btnExit.setBounds(288, 213, 90, 29);
		frame.getContentPane().add(btnExit);
		
		
		
	}

	public JFrame getFrame() {
		return frame;
	}
	}


