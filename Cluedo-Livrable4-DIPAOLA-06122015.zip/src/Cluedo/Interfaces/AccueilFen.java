package Cluedo.Interfaces;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;


public class AccueilFen {

	private JFrame frmClueado;

	/**
	 * Launch the application.
	 */
	public static void main() {
            EventQueue.invokeLater(new Runnable() {
                public void run() {
                    try {
                        AccueilFen window = new AccueilFen();
                        window.frmClueado.setVisible(true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
	}

	/**
	 * Create the application.
	 */
	public AccueilFen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		final RegisterFen fen = new RegisterFen();
		final SoloFen sol = new SoloFen();
		frmClueado = new JFrame();
		frmClueado.setTitle("CLUDEO");
		frmClueado.setBounds(100, 100, 750, 500);
		frmClueado.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmClueado.getContentPane().setLayout(null);
		JButton btnNewButton = new JButton("Solo");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			sol.getFrame().setVisible(true);
				
			}
		});
		
		btnNewButton.setBounds(80, 133, 118, 50);
		frmClueado.getContentPane().add(btnNewButton);
		final JTextPane txtpnSolon = new JTextPane();
		txtpnSolon.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
		txtpnSolon.setEditable(false);
		txtpnSolon.setEnabled(false);
		txtpnSolon.setText("Solo \r\n        Start a quick solo match.\r\nReferee\r\n\tStart refereeing a match.\r\nRegister\r\n\tRegister to a match.\r\nExit\r\n\tExit program.");
		txtpnSolon.setBounds(206, 214, 355, 178);
		frmClueado.getContentPane().add(txtpnSolon);
		
		JButton btnNewButton_1 = new JButton("Referee");
		// Implementer referee
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtpnSolon.setText("*****************");
				
			}
		});
		
		
		btnNewButton_1.setBounds(256, 133, 118, 50);
		frmClueado.getContentPane().add(btnNewButton_1);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fen.getFrame().setVisible(true);
				
			}
		});
		btnRegister.setBounds(428, 133, 118, 50);
		frmClueado.getContentPane().add(btnRegister);
		
		JLabel lblWelcomeToThe = new JLabel("WELCOME TO THE CLUEDO GAME !");
		lblWelcomeToThe.setFont(new Font("SimSun", Font.BOLD | Font.ITALIC, 15));
		lblWelcomeToThe.setBounds(167, 26, 392, 50);
		frmClueado.getContentPane().add(lblWelcomeToThe);
		
		JButton exit= new JButton("Exit");
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] options = new String[2];
				options[0] = new String("YES");
			options[1] = new String("NO");
				int  option =JOptionPane.showOptionDialog(frmClueado.getContentPane(),"Are you sure you want to quit?","Quit", 0,JOptionPane.INFORMATION_MESSAGE,null,options,null);
					if(option ==0)
						System.exit(0);
			}
		});
		exit.setBounds(580, 133, 118, 50);
		frmClueado.getContentPane().add(exit);
		
		
	}

	public JFrame getFrmClueado() {
		return frmClueado;
	}		
}

