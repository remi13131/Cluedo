package Cluedo;

import Cluedo.TheGame.Game;
import java.io.IOException;

public class Cluedo {

	public static void main(String[] args) throws IOException {
            new Game().launchGame(); //Démarrage de l'application
	}

}
