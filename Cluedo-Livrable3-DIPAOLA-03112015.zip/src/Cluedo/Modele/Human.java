package Cluedo.Modele;

public class Human extends Player{   
    public Human() {
        super();
        this.setType("human");
    }
    
    public Human(int i, String nom){
        super(i, nom);
        this.setType("human");
    }
}
