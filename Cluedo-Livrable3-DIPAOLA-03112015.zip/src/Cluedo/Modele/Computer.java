package Cluedo.Modele;

import Cluedo.Helper.Help;
import Cluedo.Helper.Utils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class Computer extends Player {
    Help help = new Help();
    
    ArrayList<Card> playedCards = new ArrayList<Card>();
    Card guessedSuspect = new Card();
    Card guessedRoom = new Card();
    Card guessedWeapon = new Card();
    
    Card lastSuggestRoom;
    Card lastSuggestWeapon;
    Card lastSuggestSuspect;
    
    public int nbDisprovedPlayer = 0;
    
    public Computer(){
        super();
        this.setType("computer");
    }
    
    public Computer(int i, String nom){
        super(i, nom);
        this.setType("computer");
    }

    public ArrayList<Card> getPlayedCards() {
        return playedCards;
    }

    public Card getGuessedSuspect() {
        return guessedSuspect;
    }

    public void setGuessedSuspect(Card guessedSuspect) {
        this.guessedSuspect = guessedSuspect;
    }

    public Card getGuessedRoom() {
        return guessedRoom;
    }

    public void setGuessedRoom(Card guessedRoom) {
        this.guessedRoom = guessedRoom;
    }

    public Card getGuessedWeapon() {
        return guessedWeapon;
    }

    public void setGuessedWeapon(Card guessedWeapon) {
        this.guessedWeapon = guessedWeapon;
    }

    public Card getLastSuggestRoom() {
        return lastSuggestRoom;
    }

    public void setLastSuggestRoom(Card lastSuggestRoom) {
        this.lastSuggestRoom = lastSuggestRoom;
    }

    public Card getLastSuggestWeapon() {
        return lastSuggestWeapon;
    }

    public void setLastSuggestWeapon(Card lastSuggestWeapon) {
        this.lastSuggestWeapon = lastSuggestWeapon;
    }

    public Card getLastSuggestSuspect() {
        return lastSuggestSuspect;
    }

    public void setLastSuggestSuspect(Card lastSuggestSuspect) {
        this.lastSuggestSuspect = lastSuggestSuspect;
    }
    
    public ArrayList<String> makeComputerOrder(){
        ArrayList<Card> allCards=help.Cards;
        
        ArrayList<Card> possibleSuspect = new ArrayList<Card>();
        ArrayList<Card> possibleWeapons = new ArrayList<Card>();
        ArrayList<Card> possibleRooms = new ArrayList<Card>();
        
        ArrayList<Card> possibleAccuseSuspect = new ArrayList<Card>();
        ArrayList<Card> possibleAccuseWeapons = new ArrayList<Card>();
        ArrayList<Card> possibleAccuseRooms = new ArrayList<Card>();
        
        int nbRooms=0, nbWeapons=0, nbSuspects=0;
        int nbRooms2=0, nbWeapons2=0, nbSuspects2=0;
        
        ArrayList<String> Ordre = new ArrayList<String>();
        Ordre.add("move");
        
        if(!guessedSuspect.getName().equals("") && !guessedRoom.getName().equals("") && !guessedWeapon.getName().equals("")){
            Ordre.add("accuse");
            Ordre.add(guessedSuspect.getName());
            Ordre.add(guessedRoom.getName());
            Ordre.add(guessedWeapon.getName());
            return Ordre;
        }
        
        for(Card card : allCards)
            if(!this.isKnownClue(card)){
                if(card.getType().equals("Suspect")) {
                    nbSuspects++;nbSuspects2++;
                    possibleSuspect.add(card);
                    possibleAccuseSuspect.add(card);
                }
                else if(card.getType().equals("Weapons")) {
                    nbWeapons++;nbWeapons2++;
                    possibleAccuseWeapons.add(card);
                    possibleWeapons.add(card);
                }
                else if(card.getType().equals("Rooms")) {
                    nbRooms++;nbRooms2++;
                    possibleAccuseRooms.add(card);
                    possibleRooms.add(card);
                }
            }        
        
        for(Card card : playedCards)
            if(!this.isKnownClue(card)){
                if(card.getType().equals("Suspect")) {
                    nbSuspects++;
                    possibleSuspect.add(card);
                }
                else if(card.getType().equals("Weapons")) {
                    nbWeapons++;
                    possibleWeapons.add(card);
                }
                else if(card.getType().equals("Rooms")) {
                    nbRooms++;
                    possibleRooms.add(card);
                }
            }
        
        if(possibleAccuseRooms.size()==1 && possibleAccuseSuspect.size()==1 && possibleAccuseWeapons.size()==1){
            Ordre.add("accuse");
            Ordre.add(possibleAccuseSuspect.get(0).getName());
            Ordre.add(possibleAccuseRooms.get(0).getName());
            Ordre.add(possibleAccuseWeapons.get(0).getName());
            return Ordre;
        }
        
        String Room="", Suspect="", Weapon="";
        float chanceRoom, chanceWeapon, chanceSuspect;
        if(possibleAccuseRooms.size()==1){
            chanceRoom=1f;
            Room=possibleAccuseRooms.get(0).getName();
        }
        else {
            chanceRoom=1f/nbRooms2;
            Collections.shuffle(possibleRooms);
            Room=possibleRooms.get(0).getName();
        }
        
        if(possibleAccuseSuspect.size()==1){ 
            Suspect=possibleAccuseSuspect.get(0).getName();
            chanceSuspect=1f;
        }
        else {
            chanceSuspect=1f/nbSuspects2;
            Collections.shuffle(possibleSuspect);
            Suspect=possibleSuspect.get(0).getName();
        }
        
        if(possibleAccuseWeapons.size()==1){
            chanceWeapon=1f/nbSuspects2;
            Weapon=possibleAccuseWeapons.get(0).getName();
        }
        else {
            chanceWeapon=1f/nbWeapons2;
            Collections.shuffle(possibleWeapons);
            Weapon=possibleWeapons.get(0).getName();
        }
        
        boolean accuse=false;
        
        float chances = chanceRoom*chanceSuspect*chanceWeapon;
        if(chances>=0.25) accuse=true;
        
        if(accuse) Ordre.add("accuse");
        else Ordre.add("suggest");
        Ordre.add(Room);
        Ordre.add(Suspect);
        Ordre.add(Weapon);
        
        lastSuggestRoom=help.nameToCard(Room);
        lastSuggestSuspect=help.nameToCard(Suspect);
        lastSuggestWeapon=help.nameToCard(Weapon);
        
        playedCards.add(lastSuggestRoom);
        playedCards.add(lastSuggestSuspect);
        playedCards.add(lastSuggestWeapon);
        
        return Ordre;
    }
    
    public Card chooseCard(ArrayList<Card> Info){
        Collections.shuffle(Info);
        return Info.get(0);
    }
}
