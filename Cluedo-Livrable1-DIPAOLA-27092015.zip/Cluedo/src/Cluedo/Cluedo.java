package Cluedo;

import Cluedo.TheGame.Game;

public class Cluedo {

	public static void main(String[] args) {
		new Game().launchGame(); //Démarrage de l'application
	}

}
